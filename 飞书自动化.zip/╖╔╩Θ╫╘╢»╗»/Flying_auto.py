"""
编写人：胡宏
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep
from selenium.webdriver.common.keys import Keys
import unittest


class FlyingTest(unittest.TestCase):
    def setUp(self):
        # 创建Chrome浏览器实例
        self.driver = webdriver.Chrome()
        # 最大化浏览器窗口
        self.driver.maximize_window()

    def tearDown(self):
        # 关闭浏览器实例
        self.driver.quit()

    def test_feishu_image(self):
        #前往飞书网址
        self.driver.get('https://www.feishu.cn/')
        # 通过CSS_SELECTOR来定位并关闭弹出的使用弹窗
        self.driver.find_element(By.CSS_SELECTOR, '[data-elem-id="yNjja0ipAf"]').click()
        # 等待
        sleep(2)
        # 通过LINK_TEXT定位登录并点击登录按钮
        self.driver.find_element(By.LINK_TEXT, '登录').click()
        sleep(2)
        # 定位右上角图案，点击切换为账号登录
        self.driver.find_element(By.XPATH,'//*[@id="root"]/div/div[2]/div[2]/div[1]/div[2]/div/div/div[1]/div/span').click()
        sleep(2)
        # 定位输入手机号码文本框并输入手机号
        phone = self.driver.find_element(By.CLASS_NAME, 'mobile-input-phone').send_keys('13687993157')
        sleep(2)
        # 定位隐私弹窗复选框并勾选
        self.driver.find_element(By.CLASS_NAME, 'ud__checkbox__input').click()
        sleep(2)

        #定位点击下一步按钮并点击
        self.driver.find_element(By.XPATH, '//button[@data-test="login-phone-next-btn"]').click()
        sleep(2)

        # 进入验证码页面，切换为密码登录
        self.driver.find_element(By.XPATH, '//*[@id="root"]/div/div[2]/div[2]/div[1]/div/div/div[3]/div/div[2]/div/div/div/div/div[2]/button').click()
        sleep(2)

        # 输入密码
        self.driver.find_element(By.CLASS_NAME, "ud__native-input[data-test='login-pwd-input']").send_keys(
            "Hz123456789")
        sleep(2)

        # 点击下一步进行登录
        self.driver.find_element(By.XPATH,
                                           '//*[@id="root"]/div/div[2]/div[2]/div[1]/div/div/div[3]/div/div[3]/div/button').click()

        sleep(2)

        # 点击选择岗位
        self.driver.find_element(By.CLASS_NAME, "user-list-item").click()
        sleep(2)

        # 点击九个点
        self.driver.find_element(By.CLASS_NAME, "_pp-product-container").click()

        # 等待下拉列表出现并点击消息中心
        wait = WebDriverWait(self.driver, 10)
        wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@title='消息']"))).click()

        # 在打开新链接之前获取当前窗口句柄
        original_window =self.driver.current_window_handle

        # 等待新标签页加载完成，在新标签页中打开了一个新窗口，因此窗口总数变为2
        WebDriverWait(self.driver, 10).until(
            EC.number_of_windows_to_be(2)
        )

        # 获取所有窗口句柄
        all_window_handles = self.driver.window_handles

        # 切换到新标签页
        new_window_handle = [handle for handle in all_window_handles if handle != original_window][0]
        self.driver.switch_to.window(new_window_handle)

        # 等待页面中的元素收件箱出现
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//div[@class="feedFilterHeader-left"]//span[text()="收件箱"]'))
        )

        # 点击联系人test2
        self.driver.find_element(By.CSS_SELECTOR, 'div.avatarWithBadge img.larkc-avatar-img').click()
        sleep(5)

        # 定位编辑器并点击
        editor_container = self.driver.find_element(By.CLASS_NAME, 'lark-editor-container').click()

        # 获取编辑器中的输入框元素并输入1111
        editor_input = self.driver.find_element(By.CLASS_NAME, 'lark-editor')
        editor_input.send_keys('1111')

        # 等待一段时间，观察是否输入成功
        sleep(2)
        # 模拟按下回车键
        editor_input.send_keys(Keys.RETURN)
        # 等待一段时间，观察是否回车发送成功
        sleep(2)


